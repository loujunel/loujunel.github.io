class Employee {

    constructor(name, salary, task1, task2, companyName= 'MHA'){
        this.task1 = task1;
        this.task2 = task2;
        this.name = name;
        this.salary = salary;
        this.companyName = companyName;
        this.projects = [];
    }

    introduce(){
        console.log(`Hi, my name is ${this.name}.`)
    }

    perform1(){
        console.log(`I can perform the following task: ${this.task1}.`)
    }

    perform2(){
        console.log(`I can also perform this: ${this.task2}.`)
    }

    printSalary(){
        console.log(`${this.name}'s salary is $${this.salary}.`)
    }

    worksAt(){
        console.log(`I work at ${this.companyName}.`)
    }

    createNewProjects(project){
        this.projects.push(project);
        console.log(`New project: ${project} added by Product Owner`);
        console.log(`Projects List: ${this.projects}`);
    }
}

module.exports = Employee;