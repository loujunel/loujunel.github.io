const Employee = require("./employee");

class Developer extends Employee{
    constructor(name, salary, specialty, companyName){
        super(name, salary, companyName);
        this.specialty = specialty;
    }

    specialize(){
        console.log(`I am a web developer specializing in ${this.specialty}.`)
    }
}

const izuku = new Developer("Izuku", 2000, "front-end development", this.companyName);

izuku.introduce();
izuku.printSalary();
izuku.specialize();
izuku.worksAt();
