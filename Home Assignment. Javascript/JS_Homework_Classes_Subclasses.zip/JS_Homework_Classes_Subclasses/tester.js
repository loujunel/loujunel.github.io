const Employee = require("./employee");

class HumanResource extends Employee{
    constructor(name, task1, task2){
        super(name);
        this.task1 = task1;
        this.task2 = task2;
    }
}

const izeke = new HumanResource("Izeke", "Say that a code passes", "Say that a code is rejected", this.companyName);

izeke.introduce();
izeke.perform1();
izeke.perform2();
izeke.worksAt();