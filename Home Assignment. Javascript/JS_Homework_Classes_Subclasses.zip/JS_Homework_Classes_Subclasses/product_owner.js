const Employee = require("./employee");

class TeamLead extends Employee{
    constructor(name, task1){
        super(name);
        this.task1 = task1;
    }
}

const izoko = new TeamLead("Izoko", "Create new projects", this.companyName);

izoko.introduce();
izoko.perform1();
izoko.worksAt();
izoko.createNewProjects("Test 1");
izoko.createNewProjects("Test 2");
izoko.createNewProjects("Test 3");