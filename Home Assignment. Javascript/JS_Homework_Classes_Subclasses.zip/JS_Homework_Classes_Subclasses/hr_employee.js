const Employee = require("./employee");

class HumanResource extends Employee{
    constructor(name, task1){
        super(name);
        this.task1 = task1;
    } 
}

const izaka = new HumanResource("Izaka", "Hire an employee", this.companyName);

izaka.introduce();
izaka.perform1();
izaka.worksAt();
