const Employee = require("./employee");

class TeamLead extends Employee{
    constructor(name, task1){
        super(name);
        this.task1 = task1;
    }
}

const iziki = new TeamLead("Iziki", "Give instructions to other employees", this.companyName);

iziki.introduce();
iziki.perform1();
iziki.worksAt();
