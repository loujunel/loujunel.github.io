let birth_month = 0;
const current_month = new Date().getMonth();
const birth_year = 1999;
let current_year = new Date().getFullYear();
let age = current_year - birth_year;

console.log(`Patient's age: ${age}`);

current_year -= 1;
age = current_year - birth_year;

if(birth_month<=current_month){
    age++;
}

console.log(`Patient's accurate age: ${age}`);
