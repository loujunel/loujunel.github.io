function toHours(seconds){
    hours = Math.floor(seconds/3600);
    remainder = seconds%3600;
    return {
        hours: hours,
        remainder: remainder,
    }
}

function toMinutes(seconds){
    /* I modified the value for minutes as it returns the full value in
    minutes, please correct me if I'm wrong on this, thank you! */
    minutes = Math.floor((seconds/60)%60);
    remainder = seconds%60;
    return {
        minutes: minutes,
        remainder: remainder,
    }
}

function humanDuration(duration){
    hoursObject = toHours(duration);
    minutesObject = toMinutes(duration);
    seconds = minutesObject.remainder;
    return console.log(`The formatted duration of ${duration} is ${hoursObject.hours}${hoursObject.hours>1?" Hours":" Hour"}, ${minutesObject.minutes} ${minutesObject.minutes > 1? "Minutes": "Minute"} and ${seconds} ${seconds > 1? "Seconds": "Second"}.`);
}

humanDuration(4800);
humanDuration(5212);
humanDuration(300);