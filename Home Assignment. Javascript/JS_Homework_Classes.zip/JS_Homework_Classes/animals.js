class Animal {

    constructor(name, sound) {
        this.name = name;
        this.sound = sound;
    }

    speak(){
        console.log(`${this.sound}! I am ${this.name}`)
    }

    isEating(){
        console.log(`${this.name} is currently eating...`)
    }
}

const cat = new Animal("cat", "Meow");
const dog = new Animal("dog", "Arf");
const bird = new Animal("bird", "Tweet");
const tiger = new Animal("tiger", "Rawr");

cat.speak();
dog.speak();
bird.speak();
tiger.speak();
cat.isEating();
dog.isEating();
bird.isEating();
tiger.isEating();