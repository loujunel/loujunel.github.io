const width = 16;
const length = 20;

perimeter = 2* (length + width);

console.log(`Width: ${width}`);
console.log(`Length: ${length}`);
console.log(`Perimeter: ${perimeter}`);