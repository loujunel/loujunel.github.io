const arr = [
    "Web Developer",
    "Refocus",
    "Web Developer",
    "Web Developer",
    "Refocus",
    "Awesome"
];

function countElements(arr){
    const count = {};
    arr.forEach(function(element) {
       count[element] = (count[element] || 0) + 1;
    });
    console.log(count);
};

countElements(arr);

// const countElements = (arr) => {
//     const count = {};
//     arr.forEach(element => {
//       count[element] = (count[element] || 0) + 1;
//     });
//     console.log(count);
//   };
  
//   countElements(arr);