const flowers = ["rose", "star gazer","tulips","sunflower"];

//I initially used the Run and Debug feature of VSCode, but somehow it does not
//display anything (or I may be using it incorrectly) so i did the following

//Attempted to recreated some of the lines one by one to simulate error
//console.logged to make sure I am getting the correct array length

// uncomment me
// console.log(flowers.length)

//result is 4, which is the correct length

//console.logged each element in the array to make sure looping statement is correct

// uncomment me
// for(i=0;i<=flowers.length;i++){
//     console.log(flowers[i])
// }

//it console.logs all of the elements, so looping statement is correct, i.e., the index and length

//for the code below, the comment states that the intended result is for the length of each individual
//strings. the spelling of the method "length" is noticeably incorrect, so i corrected that first.

//commented incorrect code

//count the length of the strings inside the Array

// for(i=0;i<=flowers.length;i++){
//     console.log(flowers[0].lentgh)
// }

//uncomment me
// for(i=0;i<=flowers.length;i++){
//     console.log(flowers[0].length)
// }

//from the code above, I also noticed that while the loop is correct, it is logging the same array index which 
//is index[0] when each loop is executed, so I changed the index to be equal to the loop index of the for loop

//uncomment me
// for(i=0;i<=flowers.length;i++){
//     console.log(flowers[i].length)
// }

//finally, the debugger was able to log an error: Cannot read properties of undefined (reading 'length')
//I Googled this error and found out that this means that I am trying to access an object but that object is not present.
//Since the length of the array was known at 4, and the initial declaration of the loop index was at value 0,
//this means that the loop will start counting from 0 to 4, or 5 elements in total, when the array only has 4
//elements. It is trying to access that 5th element. To prevent this, I can adjust the loop index to either start at 1 and
//end when it is equal to OR less than the array length, or have the loop index start at 0 but end when it is less than the
//array length.

//Solution 1:
for(i=0;i<flowers.length;i++){
    console.log(flowers[i].length)
}
//Solution 2:
for(i=1;i<flowers.length;i++){
    console.log(flowers[i].length)
}